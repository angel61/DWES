<div class="centro">
    <form name="frm1" action="index.php" method="post">
        <?php $this->printProvincias(); ?>
        <input type="submit">
    </form>
</div>