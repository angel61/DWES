<div class="centro">
        <?php $this->printPisos($_REQUEST["slcCiudad"]); ?>
</div>