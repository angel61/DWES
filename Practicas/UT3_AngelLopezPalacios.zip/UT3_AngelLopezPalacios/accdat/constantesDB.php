   <?php
    const host="localhost";
    const us="root";
    const pw="";
    const bd="nba";
    const puerto=3306;
