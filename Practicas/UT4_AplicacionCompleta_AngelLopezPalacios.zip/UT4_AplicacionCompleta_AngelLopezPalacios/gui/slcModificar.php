<div class="centro">
    <form name="frm2" action="index.php" method="post">
        <?php $this->printUsuario("Update"); ?>
        <input type="submit">
    </form>
</div>