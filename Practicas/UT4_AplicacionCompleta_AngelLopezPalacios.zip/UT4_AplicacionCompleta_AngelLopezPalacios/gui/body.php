<div>
    <form action="index.php" method="post">
        <button name="btnAnnadir">Añadir</button>
        <button name="btnModificar">Modificar</button>
        <button name="btnMostrar">Mostrar</button>
    </form>
</div>